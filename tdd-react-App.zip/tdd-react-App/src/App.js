import "./App.css";
import AwesomeCounter from "./components/AwesomeCounter";

function App() {
  return (
    <div>
      <Counter />
    </div>
  );
}

export default App;
